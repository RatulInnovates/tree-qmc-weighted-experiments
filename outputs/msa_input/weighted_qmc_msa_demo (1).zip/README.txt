WEIGHTED TREE-QMC MSA DEMO DATA
=================================

These are tiny synthetic teaching files only. They are designed to let you
practice the pipeline:

MSA -> gene-tree estimation -> gene-tree file -> TREE-QMC.

The "poor" files are deliberately altered alignment examples, not realistic
simulations of alignment error. Do NOT use them as final research data.

Suggested first test:
1. Run your gene-tree estimator separately on clean_gene1.fasta and
   poor_gene1_demo.fasta.
2. Repeat for gene2.
3. Put the resulting Newick gene trees into one file, e.g. gene_trees.tre,
   one tree per line.
4. Run TREE-QMC on that gene-tree file.

TREE-QMC expects gene trees, not FASTA/MSA files.
